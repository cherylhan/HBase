package cn.edu.bjtu.entity;

public class Entity {
	private String pId;
	private String cpuValue;
	private String memoryValue;
	public Entity(String pId,String cpuValue,String memoryValue){
		this.pId=pId;
		this.cpuValue=cpuValue;
		this.memoryValue=memoryValue;
	}
	
	public String getpId() {
		return pId;
	}

	public void setpId(String pId) {
		this.pId = pId;
	}

	public String getCpuValue() {
		return cpuValue;
	}
	public void setCpuValue(String cpuValue) {
		this.cpuValue = cpuValue;
	}
	public String getMemoryValue() {
		return memoryValue;
	}
	public void setMemoryValue(String memoryValue) {
		this.memoryValue = memoryValue;
	}
	
	
	
}
