package cn.edu.bjtu.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import cn.edu.bjtu.entity.Entity;
import cn.edu.bjtu.entity.HbaseTask;
import cn.edu.bjtu.lh.CmdExecuter;
import cn.edu.bjtu.lh.HBaseExecuter;
import net.sf.json.JSONObject;

@SuppressWarnings("serial")
public class FetchData extends HttpServlet{
	public void doPost(HttpServletRequest request,HttpServletResponse response){
		String userId="1";
		String taskId="11";
		HttpSession session=request.getSession();
		CmdExecuter cmd=new CmdExecuter();
		try {
			String pId=cmd.start("Reader");
			session.setAttribute("pId",pId);
			Entity entity=cmd.getInfo(pId);
			HBaseExecuter exe=new HBaseExecuter(userId);
			HbaseTask task=new HbaseTask(taskId,entity.getCpuValue(),entity.getMemoryValue(),userId);
			try {
				exe.insert(task);
			} catch (Exception e) {
				e.printStackTrace();
			}
			JSONObject json=JSONObject.fromObject(entity);
			PrintWriter out=response.getWriter();
			out.print(json.toString());
			out.flush();
			out.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	public void doGet(HttpServletRequest request,HttpServletResponse response){
		doPost(request,response);
	}
}
