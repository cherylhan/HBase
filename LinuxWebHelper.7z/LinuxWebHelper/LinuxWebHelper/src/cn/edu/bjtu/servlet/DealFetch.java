package cn.edu.bjtu.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang.StringUtils;

import cn.edu.bjtu.lh.CmdExecuter;
@SuppressWarnings("serial")
public class DealFetch extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String pId=null;
		HttpSession session=request.getSession();
		response.setCharacterEncoding("utf-8");
		Object obj=session.getAttribute("pId");
		if(obj!=null)pId=obj.toString();
		String cmd=request.getParameter("cmd");
		String info="error";
		PrintWriter out=response.getWriter();
		if(StringUtils.isNotEmpty(pId) && StringUtils.isNotEmpty(cmd)){
			CmdExecuter exe=new CmdExecuter();
			if(cmd.equals("go")){
				exe.go(pId);
				info="go-success";
			}else if(cmd.equals("stop")){
				exe.stop(pId);
				info="stop-success";
			}else{
				exe.kill(pId);
				info="kill-success";
			}
		}
		System.out.println("info:"+info);
		out.print(info);
		out.flush();
		out.close();
	}

}
