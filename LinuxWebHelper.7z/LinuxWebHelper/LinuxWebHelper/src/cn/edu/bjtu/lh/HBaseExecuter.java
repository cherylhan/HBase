package cn.edu.bjtu.lh;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.HColumnDescriptor;
import org.apache.hadoop.hbase.HTableDescriptor;
import org.apache.hadoop.hbase.client.Get;
import org.apache.hadoop.hbase.client.HBaseAdmin;
import org.apache.hadoop.hbase.client.HTable;
import org.apache.hadoop.hbase.client.HTableInterface;
import org.apache.hadoop.hbase.client.HTablePool;
import org.apache.hadoop.hbase.client.Put;
import org.apache.hadoop.hbase.client.Result;
import org.apache.hadoop.hbase.client.ResultScanner;
import org.apache.hadoop.hbase.client.Scan;
import org.apache.hadoop.hbase.filter.CompareFilter;
import org.apache.hadoop.hbase.filter.Filter;
import org.apache.hadoop.hbase.filter.FilterList;
import org.apache.hadoop.hbase.filter.RowFilter;
import org.apache.hadoop.hbase.filter.SingleColumnValueFilter;
import org.apache.hadoop.hbase.filter.SubstringComparator;
import org.apache.hadoop.hbase.filter.CompareFilter.CompareOp;
import org.apache.hadoop.hbase.util.Bytes;

import cn.edu.bjtu.entity.HbaseTask;
import cn.edu.bjtu.entity.TBData;

public class HBaseExecuter{
	private String userId=null;
	public HBaseExecuter(String userId){
		this.userId=userId;
	}
	//HBase锟斤拷锟斤拷
	private static Configuration cfg=null;
	static HTablePool tp=null;
	static{
			cfg=HBaseConfiguration.create();
			tp=new HTablePool(cfg,10);
	}
	//锟斤拷锟斤拷锟斤拷
	private void create(String tableName)throws Exception{
			HBaseAdmin admin =new HBaseAdmin(cfg);
			if(admin.tableExists(tableName)){
				System.exit(0);
			}else{
				HTableDescriptor tableDesc=new HTableDescriptor(tableName);
				tableDesc.addFamily(new HColumnDescriptor(ConstantUtility.COLUMN_GROUP));
				admin.createTable(tableDesc);
			}
			admin.close();
	}
	
	//锟斤拷锟斤拷锟斤拷
	private void put(String tablename,String rowKey,String columnFamily,String column,String data)throws Exception{
				HTable table=new HTable(cfg,tablename);
				Put p=new Put(Bytes.toBytes(rowKey));
				p.add(Bytes.toBytes(columnFamily),Bytes.toBytes(column),Bytes.toBytes(data));
				table.put(p);
				table.close();
	}
	
	//锟斤拷示锟斤拷锟斤拷锟斤拷锟�
	public  ResultScanner scan(String tablename)throws Exception{
			HTable table=new HTable(cfg,tablename);
			Scan s=new Scan();
			ResultScanner rs=table.getScanner(s);
			table.close();
			return rs;
	}
	
	
     public String insert(HbaseTask entity)throws Exception{
    	create(ConstantUtility.TABLE_NAME);
		SimpleDateFormat sdf=new SimpleDateFormat("yyyyMMddhhmmss");
		String time=sdf.format(System.currentTimeMillis());
		String rowKey=entity.getUserId()+time+entity.getTaskId(); 
		put(ConstantUtility.TABLE_NAME,rowKey,ConstantUtility.COLUMN_GROUP,"cpu",entity.getCup());	
		put(ConstantUtility.TABLE_NAME,rowKey,ConstantUtility.COLUMN_GROUP,"memory",entity.getMemory());	
		put(ConstantUtility.TABLE_NAME,rowKey,ConstantUtility.COLUMN_GROUP,"userId",entity.getUserId());	
		put(ConstantUtility.TABLE_NAME,rowKey,ConstantUtility.COLUMN_GROUP,"taskId",entity.getTaskId());	
    	return rowKey;
    }
	//锟斤拷取锟斤拷锟�
	public Result getResult(String tablename,String rowKey)throws Exception{
			HTable table=new HTable(cfg,tablename);
			Get g=new Get(Bytes.toBytes(rowKey));
			Result result =table.get(g);
			table.close();
			return result;
	}
	
	
	// GET HBase Table
    public static HTableInterface getTable(String tableName){
    	if(StringUtils.isEmpty(tableName)) return null;
    	return tp.getTable(getBytes(tableName));
    }
    
    //to byte array
    public static byte[] getBytes(String value){
    	if(value==null) value="";
    	return Bytes.toBytes(value);
    }
    
    //reserach data
    public static TBData getDataMapRow(String tableName,String data,
    		Integer currentPage,Integer pageSize)throws IOException{
//    	List<Map<String,String>> maplist=null;
//    	maplist=new LinkedList<Map<String,String>>();
    	List<HbaseTask> maplist=null;
    	maplist=new LinkedList<HbaseTask>();
    	 ResultScanner scanner=null;
    	 //create page object
    	 TBData tbData=null;
    	 try {
			if(pageSize==null || pageSize==0l)
				 pageSize=100;
			 if(currentPage==null||currentPage==0){
				 currentPage=1;
			 }
			 
			 Integer firstPage =(currentPage-1)*pageSize;
			 Integer endPage=firstPage+pageSize;
			 
			 //get hbase object from pool
			 HTableInterface table =getTable(tableName);
			 RowFilter rf=new RowFilter(CompareFilter.CompareOp.EQUAL,
			new SubstringComparator(data));
			 Scan scan=new Scan();
			 scan.setFilter(rf);
			 scan.setCaching(2);
			 scan.setCacheBlocks(false);
			 scanner=table.getScanner(scan);
			 int i=0;
			 List<byte[]> rowList =new LinkedList<byte[]>();
			 for(Result result:scanner){
				 String row=toStr(result.getRow());
				 if(i>=firstPage && i<endPage){
					 rowList.add(getBytes(row));
				 }
				 i++;
			 }
			 // get rowkey GetObject
			 List<Get> getList=getList(rowList);
			 Result[] results=table.get(getList);
			 
			 // the result
			 for(Result result:results){
//				 Map<byte[],byte[]> fmap=packFamilyMap(result);
//				 Map<String,String> rmap=packRowMap(fmap);
				 String taskId=Bytes.toString(result.getValue(getBytes("task"), getBytes("taskId")));
				 String cpu=Bytes.toString(result.getValue(getBytes("task"), getBytes("cpu")));
				 String memory=Bytes.toString(result.getValue(getBytes("task"), getBytes("memory")));
				 String userId=Bytes.toString(result.getValue(getBytes("task"), getBytes("userId")));
				 HbaseTask task=new HbaseTask();
				 task.setTaskId(taskId);
				 task.setCup(cpu);
				 task.setMemory(memory);
				 task.setUserId(userId);
				 
				 
				 maplist.add(task);
			 }
			 tbData=new TBData();
			 tbData.setCurrentPage(currentPage);
			 tbData.setPageSize(pageSize);
			 tbData.setTotalCount(i);
			 tbData.setResultList(maplist);
			 tbData.setTotalPage(getTotalPage(pageSize,i));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			closeScanner(scanner);
		}
    	 
    	 return tbData;
    	 
    }
    
    
    //reserach data
    public static TBData getDataMapCloumn(String tableName,String data,
    		Integer currentPage,Integer pageSize)throws IOException{
//    	List<Map<String,String>> maplist=null;
//    	maplist=new LinkedList<Map<String,String>>();
    	List<HbaseTask> maplist=null;
    	maplist=new LinkedList<HbaseTask>();
    	 ResultScanner scanner=null;
    	 //create page object
    	 TBData tbData=null;
    	 try {
			if(pageSize==null || pageSize==0l)
				 pageSize=100;
			 if(currentPage==null||currentPage==0){
				 currentPage=1;
			 }
			 
			 Integer firstPage =(currentPage-1)*pageSize;
			 Integer endPage=firstPage+pageSize;
			 
			 //get hbase object from pool
			 HTableInterface table =getTable(tableName);
			;
 
			 FilterList filterList=null;
		    	filterList=new FilterList(FilterList.Operator.MUST_PASS_ALL);
		    	
		    	SingleColumnValueFilter filter1=null;
		    filter1=new SingleColumnValueFilter(getBytes("task"),
		    		           getBytes("userId"),
		    		           CompareOp.EQUAL,
		    		           getBytes(data)
		    		);
		    filterList.addFilter(filter1);
			 Scan scan=new Scan();
			 scan.setFilter(filterList);

			 scan.setCaching(2);
			 scan.setCacheBlocks(false);
			 scanner=table.getScanner(scan);
			 int i=0;
			 List<byte[]> rowList =new LinkedList<byte[]>();
			 for(Result result:scanner){
				 String row=toStr(result.getRow());
				 if(i>=firstPage && i<endPage){
					 rowList.add(getBytes(row));
				 }
				 i++;
			 }
			 // get rowkey GetObject
			 List<Get> getList=getList(rowList);
			 Result[] results=table.get(getList);
			 
			 // the result
			 for(Result result:results){
//				 Map<byte[],byte[]> fmap=packFamilyMap(result);
//				 Map<String,String> rmap=packRowMap(fmap);
				 String id=Bytes.toString(result.getRow());
				 String taskId=Bytes.toString(result.getValue(getBytes("task"), getBytes("taskId")));
				 String cpu=Bytes.toString(result.getValue(getBytes("task"), getBytes("cpu")));
				 String memory=Bytes.toString(result.getValue(getBytes("task"), getBytes("memory")));
				 String userId=Bytes.toString(result.getValue(getBytes("task"), getBytes("userId")));
				 HbaseTask task=new HbaseTask();
				 task.setId(id);
				 task.setTaskId(taskId);
				 task.setCup(cpu);
				 task.setMemory(memory);
				 task.setUserId(userId);
				 
				 
				 maplist.add(task);
			 }
			 tbData=new TBData();
			 tbData.setCurrentPage(currentPage);
			 tbData.setPageSize(pageSize);
			 tbData.setTotalCount(i);
			 tbData.setResultList(maplist);
			 tbData.setTotalPage(getTotalPage(pageSize,i));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			closeScanner(scanner);
		}
    	 
    	 return tbData;
    	 
    }
    
    public static TBData getData2MapCloumn(String tableName,String[] data,
    		Integer currentPage,Integer pageSize)throws IOException{
//    	List<Map<String,String>> maplist=null;
//    	maplist=new LinkedList<Map<String,String>>();
    	List<HbaseTask> maplist=null;
    	maplist=new LinkedList<HbaseTask>();
    	 ResultScanner scanner=null;
    	 //create page object
    	 TBData tbData=null;
    	 try {
			if(pageSize==null || pageSize==0l)
				 pageSize=100;
			 if(currentPage==null||currentPage==0){
				 currentPage=1;
			 }
			 
			 Integer firstPage =(currentPage-1)*pageSize;
			 Integer endPage=firstPage+pageSize;
			 
			 //get hbase object from pool
			 HTableInterface table =getTable(tableName);
			;
 
			 Scan scan=getScan(data[0],data[1]);
			 scanner=table.getScanner(scan);
			 int i=0;
			 List<byte[]> rowList =new LinkedList<byte[]>();
			 for(Result result:scanner){
				 String row=toStr(result.getRow());
				 if(i>=firstPage && i<endPage){
					 rowList.add(getBytes(row));
				 }
				 i++;
			 }
			 // get rowkey GetObject
			 List<Get> getList=getList(rowList);
			 Result[] results=table.get(getList);
			 
			 // the result
			 for(Result result:results){
//				 Map<byte[],byte[]> fmap=packFamilyMap(result);
//				 Map<String,String> rmap=packRowMap(fmap);
				 String id=Bytes.toString(result.getRow());
				 String taskId=Bytes.toString(result.getValue(getBytes("task"), getBytes("taskId")));
				 String cpu=Bytes.toString(result.getValue(getBytes("task"), getBytes("cpu")));
				 String memory=Bytes.toString(result.getValue(getBytes("task"), getBytes("memory")));
				 String userId=Bytes.toString(result.getValue(getBytes("task"), getBytes("userId")));
				 HbaseTask task=new HbaseTask();
				 task.setId(id);
				 task.setTaskId(taskId);
				 task.setCup(cpu);
				 task.setMemory(memory);
				 task.setUserId(userId);
				 
				 
				 maplist.add(task);
			 }
			 tbData=new TBData();
			 tbData.setCurrentPage(currentPage);
			 tbData.setPageSize(pageSize);
			 tbData.setTotalCount(i);
			 tbData.setResultList(maplist);
			 tbData.setTotalPage(getTotalPage(pageSize,i));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			closeScanner(scanner);
		}
    	 
    	 return tbData;
    	 
    }
    
    //get totalPage
    public static int getTotalPage(int PageSize,int totalCount){
    	int n=(totalCount-1)/PageSize+1;
    	return n;
    }
    
    //get scan
    private static Scan getScan(String startRow,String stopRow){
    	Scan scan=new Scan();
    	scan.setStartRow(getBytes(startRow));
    	scan.setStopRow(getBytes(stopRow));
    	return scan;
    }
    
   
    private static void closeScanner(ResultScanner scanner){
    	if(scanner!=null)
    		scanner.close();
    }
    
    //accord rowkey get collect GET
    private static List<Get> getList(List<byte[]> rowlist){
    	List<Get> list=new LinkedList<Get>();
    	for(byte[] row:rowlist){
    		Get get=new Get(row);
 
    		//get.addColumn(getBytes("task"), getBytes("taskId"));
    		get.addColumn(getBytes("task"), getBytes("taskId"));
    		get.addColumn(getBytes("task"), getBytes("cpu"));
    		get.addColumn(getBytes("task"), getBytes("memory"));
    		get.addColumn(getBytes("task"), getBytes("userId"));
    		list.add(get);
    	}
    	return list;
    }
    private static String toStr(byte[] bt){
    	return Bytes.toString(bt);
    }
    
}
