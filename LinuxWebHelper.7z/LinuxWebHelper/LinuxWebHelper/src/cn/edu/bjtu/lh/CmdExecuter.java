package cn.edu.bjtu.lh;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import cn.edu.bjtu.entity.Entity;

/*
 * ����:Shell�ű�ִ����
 * ���ڣ�2015��12��23��
 * */
public class CmdExecuter {
	/**
	 * ��������ʼִ�У�������ȡ�ļ����񣩷����߳�Id
	 * */
	public String start(String className) throws IOException{
		Process pro=run("jps -l|grep "+className+" |awk '{print $1}'");
		InputStream in = pro.getInputStream();  
		BufferedReader read = new BufferedReader(new InputStreamReader(in));  
		String id=read.readLine();
		read.close();
		return id;
	}
	/**
	 * ������ɱ���߳�
	 * @throws IOException 
	 * */
	public Boolean kill(String pId) throws IOException{
		String cmd="kill -9 "+pId;
		run(cmd);
		return !isAlive(pId,true);
	}
	/**
	 * ��������ͣ�߳�
	 * @throws IOException 
	 * */
	public Boolean stop(String pId) throws IOException{
		String cmd="kill -s stop "+pId;
		run(cmd);
		return !isAlive(pId,false);
	}
	/**
	 * ����������ִ��
	 * @throws IOException 
	 * */
	public Boolean go(String pId) throws IOException{
		String cmd="kill -s cont "+pId;
		run(cmd);
		return isAlive(pId,false);
	}
	/**
	 * ��������ȡCPU��������Ϣ 
	 * @throws IOException 
	 * */
	public String getCpu(String pId) throws IOException{
		return getInfo(pId,"cpu");
	}
	/**
	 * ��������ȡ�ڴ�����
	 * */
	public String getMemory(String pId)throws IOException{
		return getInfo(pId,"memory");
	}

	
	private String getInfo(String pId,String flag)throws IOException{
		int column = 0;
		if(flag.trim().equalsIgnoreCase("cpu"))
			column=9;
		else 
			column=10;
		String cmd="top -b -n 1|grep "+pId+"|awk '{print $"+column+"}' |sed -n '1p'";
		Process pro=run(cmd);
		InputStream in = pro.getInputStream();  
		BufferedReader read = new BufferedReader(new InputStreamReader(in));  
		String msg=read.readLine();
		read.close();
		return msg;
	}
	public Entity getInfo(String pId)throws IOException{
		String cmd="top -b -n 1|grep "+pId+"|awk '{print $9,$10}'";
		Process pro=run(cmd);
		InputStream in = pro.getInputStream();  
		BufferedReader read = new BufferedReader(new InputStreamReader(in));  
		String msg=read.readLine();
		read.close();	
		String[] info=msg.split(" ");
		Entity entity=new Entity(pId,info[0],info[1]);
		return entity;
	}
	/**
	 * ��������ѯ�����Ƿ���
	 * */
	private Boolean isAlive(String pId,Boolean isKill) throws IOException{
		String cmd="top -bn 1|grep "+pId+"|awk '{print $8}'";
		Process pro=run(cmd);
		InputStream in = pro.getInputStream();  
		BufferedReader read = new BufferedReader(new InputStreamReader(in));  
		String info=read.readLine();
		Boolean result=null;
		if(!isKill)
			result=info.trim().equals("S");
		else
			result=info!=null;
		read.close();
		return result; 
	}
	
	/**
	 * ����:����ִ�еĽ���
	 * */
	private Process run(String cmd){
		Process pro=null;
		try{
			String[] cmds = {"/bin/sh","-c",cmd};  
			pro = Runtime.getRuntime().exec(cmds);  
			pro.waitFor();
		}catch(Exception e){
			e.printStackTrace();
		}
		return pro;
	}
}
