package cn.edu.bjtu.lh;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;

public class Collector{
	CmdExecuter cmd=null;
	private String pId=null;
	private Timer timer=null;
	public Collector(String pId){
		cmd=new CmdExecuter();
		this.pId=pId;
	}
	public void closeFetch(){
		this.timer.cancel();
	}
	public void getTimeFetch(){
		timer=new Timer();
		timer.schedule(new TimerTask(){
			@Override
			public void run() {
				try {
					getInfo();
				} catch (IOException e) {
					this.cancel();
				}
			}
		},ConstantUtility.TIME_DELEY,ConstantUtility.TIME_SPAN);
	}
	private Map<String,String> getInfo() throws IOException{
		Map<String,String> map=new HashMap<String,String>();
		map.put("cpu",cmd.getCpu(pId));
		map.put("memory",cmd.getMemory(pId));
		return map;
	}
}
