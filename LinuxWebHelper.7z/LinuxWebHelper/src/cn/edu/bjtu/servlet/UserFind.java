package cn.edu.bjtu.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cn.edu.bjtu.entity.TBData;
import cn.edu.bjtu.lh.ConstantUtility;
import cn.edu.bjtu.lh.HBaseExe;

/**
 * Servlet implementation class UserFind
 */
@WebServlet("/UserFind")
public class UserFind extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UserFind() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		// TODO Auto-generated method stub
		String type=request.getParameter("type");
		String date=request.getParameter("data");
		
		if(type.equals("0")){
			if(date.equals("1")){
				findUserByDate(request,response);
			}else{
			findUserInfoAll(request,response);
			}
		}
		if(type=="1"){
			findUserById(request,response);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String type=request.getParameter("type");
		String date=request.getParameter("data");
		if(type.equals("0")){
			if(date.equals("1")){
			
				findUserByDate(request,response);
			
			}else
			findUserInfoAll(request,response);
			
		}
		if(type=="1"){
			findUserById(request,response);
		}
	}
	
	protected void findUserByDate(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String currentPage=request.getParameter("currentPage");
		String date=request.getParameter("startTime");
		if(currentPage==null||currentPage==""){
			currentPage="1";
		}
		HBaseExe hbaseExe=new HBaseExe();
		TBData tbData=hbaseExe.getDataMapRow(ConstantUtility.TABLE_NAME, date, Integer.parseInt(currentPage),ConstantUtility.SIZE);
		if(tbData.getResultList().size()==0){
			tbData=hbaseExe.getDataMapRow(ConstantUtility.TABLE_NAME, date, Integer.parseInt(currentPage)-1,ConstantUtility.SIZE);
		}
		request.setAttribute("display","block");
		request.setAttribute("tbData", tbData.getResultList());
		request.setAttribute("currentPage",tbData.getCurrentPage());
		request.getSession().setAttribute("startTime", date);
		request.getRequestDispatcher("/userlistdate.jsp").forward(request, response);
	}
	
	protected void findUserById(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String userId=request.getParameter("userId");
		String currentPage=request.getParameter("currentPage");
		if(currentPage==null||currentPage==""){
			currentPage="1";
		}
		HBaseExe hbaseExe=new HBaseExe();
		TBData tbData=hbaseExe.getDataMapCloumn(ConstantUtility.TABLE_NAME, userId, Integer.parseInt(currentPage),ConstantUtility.SIZE);
		if(tbData.getResultList().size()==0){
			tbData=hbaseExe.getDataMapCloumn(ConstantUtility.TABLE_NAME, userId, Integer.parseInt(currentPage)-1,ConstantUtility.SIZE);
		}
		request.setAttribute("tbData", tbData.getResultList());
		request.setAttribute("currentPage",tbData.getCurrentPage());
		request.getRequestDispatcher("/userlist.jsp").forward(request, response);
	}
	protected void findUserInfoAll(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String currentPage=request.getParameter("currentPage");
		if(currentPage==null||currentPage==""){
			currentPage="1";
		}
		HBaseExe hbaseExe=new HBaseExe();
	//	TBData tbData=hbaseExe.getDataMapRow(ConstantUtility.TABLE_NAME, date, Integer.parseInt(currentPage),ConstantUtility.SIZE);
		//request.setAttribute("tbData", tbData.getResultList());
		TBData tbData=hbaseExe.getDataAll(ConstantUtility.TABLE_NAME, Integer.parseInt(currentPage), ConstantUtility.SIZE);
		if(tbData.getResultList().size()==0){
			tbData=hbaseExe.getDataAll(ConstantUtility.TABLE_NAME, Integer.parseInt(currentPage)-1,ConstantUtility.SIZE);
		}
		request.setAttribute("display","block");
		request.setAttribute("currentPage",tbData.getCurrentPage());
		request.setAttribute("tbData", tbData.getResultList());
		request.getRequestDispatcher("/userlist.jsp").forward(request, response);
	}
}
